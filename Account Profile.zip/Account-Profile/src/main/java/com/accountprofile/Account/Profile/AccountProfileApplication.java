package com.accountprofile.Account.Profile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountProfileApplication.class, args);
	}

}
