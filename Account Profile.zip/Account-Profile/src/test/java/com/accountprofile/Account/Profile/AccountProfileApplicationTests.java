package com.accountprofile.Account.Profile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
